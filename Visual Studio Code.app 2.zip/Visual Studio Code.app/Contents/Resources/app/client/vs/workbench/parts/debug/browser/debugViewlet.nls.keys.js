/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/workbench/parts/debug/browser/debugViewlet.nls.keys",[],{vs_workbench_parts_debug_browser_debugViewlet:{path:"client/vs/workbench/parts/debug/browser/debugViewlet.js",keys:["variables","watch","callStack","debugStopped","breakpoints"]}});