/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/workbench/parts/debug/browser/debugViewlet.nls",[],{vs_workbench_parts_debug_browser_debugViewlet:["Variables","Watch","Call Stack","Paused on {0}.","Breakpoints"]});