/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/workbench/services/request/common/requestService.nls",[],{vs_workbench_services_request_common_requestService:["File not found"]});