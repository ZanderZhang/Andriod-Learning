# Native File Watching for Windows

- Repository: https://monacotools.visualstudio.com/DefaultCollection/Monaco/_git/FileWatcher

# Build

- Build in "Release" config
- Copy CodeHelper.exe over into this folder