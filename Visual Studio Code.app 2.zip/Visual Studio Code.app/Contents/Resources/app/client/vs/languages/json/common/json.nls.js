/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/json/common/json.nls",[],{vs_languages_json_common_json:["objects","arrays","strings","numbers","booleans","undefined"]});