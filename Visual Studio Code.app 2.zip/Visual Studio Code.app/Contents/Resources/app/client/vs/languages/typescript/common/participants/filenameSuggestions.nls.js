/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/typescript/common/participants/filenameSuggestions.nls",[],{});