/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/json/common/json.nls.keys",[],{vs_languages_json_common_json:{path:"client/vs/languages/json/common/json.js",keys:["object","array","string","number","boolean","undefined"]}});