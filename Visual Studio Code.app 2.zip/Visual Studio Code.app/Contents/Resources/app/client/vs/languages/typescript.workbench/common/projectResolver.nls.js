/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/typescript.workbench/common/projectResolver.nls",[],{"vs_languages_typescript.workbench_common_projectResolver":["Loading additional files..."]});