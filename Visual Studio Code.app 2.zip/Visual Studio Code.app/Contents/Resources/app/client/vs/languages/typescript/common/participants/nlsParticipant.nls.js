/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/typescript/common/participants/nlsParticipant.nls",[],{vs_languages_typescript_common_participants_nlsParticipant:["String needs localization"]});