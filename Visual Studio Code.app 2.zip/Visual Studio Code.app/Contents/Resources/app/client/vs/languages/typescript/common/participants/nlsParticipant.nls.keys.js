/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/typescript/common/participants/nlsParticipant.nls.keys",[],{vs_languages_typescript_common_participants_nlsParticipant:{path:"client/vs/languages/typescript/common/participants/nlsParticipant.js",keys:["missing.localize"]}});