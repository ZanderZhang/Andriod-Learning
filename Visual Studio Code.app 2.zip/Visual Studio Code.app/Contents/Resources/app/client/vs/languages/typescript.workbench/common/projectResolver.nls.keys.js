/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/typescript.workbench/common/projectResolver.nls.keys",[],{"vs_languages_typescript.workbench_common_projectResolver":{path:"client/vs/languages/typescript.workbench/common/projectResolver.js",keys:["resolve.files.N"]}});