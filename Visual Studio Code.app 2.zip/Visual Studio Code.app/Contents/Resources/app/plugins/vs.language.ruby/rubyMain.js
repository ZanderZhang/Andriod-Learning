/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports", './rubyDef', 'monaco'], function (require, exports, rubyDef, monaco) {
    monaco.Modes.registerMonarchDefinition('ruby', rubyDef.language);
    var InplaceReplaceSupport = monaco.Modes.InplaceReplaceSupport;
    InplaceReplaceSupport.register('ruby', InplaceReplaceSupport.create({
        textReplace: function (value, up) {
            return InplaceReplaceSupport.valueSetReplace(['true', 'false'], value, up);
        }
    }));
});
