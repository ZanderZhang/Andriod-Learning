/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", './abstractSupport', '../protocol', 'monaco'], function (require, exports, abstractSupport_1, Protocol, monaco) {
    var GotoDeclSupport = (function (_super) {
        __extends(GotoDeclSupport, _super);
        function GotoDeclSupport() {
            _super.apply(this, arguments);
        }
        GotoDeclSupport.prototype.findDeclaration = function (resource, position) {
            if (this.isInMemory(resource)) {
                return monaco.Promise.as(null);
            }
            var request = {
                Filename: resource.fsPath,
                Line: position.lineNumber,
                Column: position.column
            };
            return this.server().makeRequest(Protocol.GoToDefinition, request).then(function (value) {
                if (!value || !value.FileName) {
                    return;
                }
                return {
                    range: { startLineNumber: value.Line, startColumn: value.Column, endLineNumber: value.Line, endColumn: value.Column },
                    resourceUrl: new monaco.URL(monaco.URI.file(value.FileName))
                };
            });
        };
        return GotoDeclSupport;
    })(abstractSupport_1.default);
    exports.default = GotoDeclSupport;
});
