/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports", 'monaco'], function (require, exports, monaco) {
    var AbstractSupport = (function () {
        function AbstractSupport(modelService, server) {
            this._modelService = modelService;
            this._server = server;
        }
        AbstractSupport.prototype.server = function () {
            return this._server;
        };
        AbstractSupport.prototype.buffer = function (resource) {
            return AbstractSupport.buffer(this._modelService.getModel(resource));
        };
        AbstractSupport.prototype.isInMemory = function (resource) {
            return monaco.URL.fromUri(resource).isInMemory();
        };
        AbstractSupport.buffer = function (model) {
            return model.getValue(monaco.Models.EndOfLinePreference.LF, false);
        };
        return AbstractSupport;
    })();
    exports.default = AbstractSupport;
});
