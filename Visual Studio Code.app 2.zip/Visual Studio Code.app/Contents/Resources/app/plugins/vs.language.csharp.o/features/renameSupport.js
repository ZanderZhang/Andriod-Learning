/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", './abstractSupport', '../protocol', 'monaco'], function (require, exports, abstractSupport_1, Protocol, monaco) {
    var RenameSupport = (function (_super) {
        __extends(RenameSupport, _super);
        function RenameSupport() {
            _super.apply(this, arguments);
        }
        RenameSupport.prototype.rename = function (resource, position, newName) {
            if (this.isInMemory(resource)) {
                return monaco.Promise.as(null);
            }
            var word = this._modelService.getModel(monaco.URL.fromUri(resource)).getWordAtPosition(position), request;
            request = {
                WantsTextChanges: true,
                Filename: resource.fsPath,
                Line: position.lineNumber,
                Column: position.column,
                RenameTo: newName
            };
            return this.server().makeRequest(Protocol.Rename, request).then(function (response) {
                if (!response) {
                    return;
                }
                var result = {
                    currentName: word.word,
                    edits: []
                };
                response.Changes.forEach(function (change) {
                    var resource = monaco.URI.file(change.FileName);
                    change.Changes.forEach(function (change) {
                        result.edits.push(RenameSupport._convert(resource, change));
                    });
                });
                return result;
            });
        };
        RenameSupport._convert = function (resource, change) {
            return {
                resource: resource,
                newText: change.NewText,
                range: {
                    startLineNumber: change.StartLine,
                    startColumn: change.StartColumn,
                    endLineNumber: change.EndLine,
                    endColumn: change.EndColumn
                }
            };
        };
        return RenameSupport;
    })(abstractSupport_1.default);
    exports.default = RenameSupport;
});
