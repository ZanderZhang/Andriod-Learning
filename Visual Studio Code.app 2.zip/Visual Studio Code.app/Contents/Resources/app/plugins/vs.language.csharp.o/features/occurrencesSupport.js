/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", './abstractSupport', '../protocol', 'monaco'], function (require, exports, abstractSupport_1, Protocol, monaco) {
    var OccurrencesSupport = (function (_super) {
        __extends(OccurrencesSupport, _super);
        function OccurrencesSupport() {
            _super.apply(this, arguments);
        }
        OccurrencesSupport.prototype.findOccurrences = function (resource, position, strict) {
            if (this.isInMemory(resource)) {
                return monaco.Promise.as([]);
            }
            return this.server().makeRequest(Protocol.FindUsages, {
                Filename: resource.fsPath,
                Line: position.lineNumber,
                Column: position.column,
                OnlyThisFile: true,
                ExcludeDefinition: false
            }).then(function (res) {
                return !res || !Array.isArray(res.QuickFixes)
                    ? []
                    : res.QuickFixes.map(OccurrencesSupport.asOccurrence);
            });
        };
        OccurrencesSupport.asOccurrence = function (quickFix) {
            return {
                range: {
                    startLineNumber: quickFix.Line,
                    startColumn: quickFix.Column,
                    endLineNumber: quickFix.EndLine,
                    endColumn: quickFix.EndColumn
                }
            };
        };
        return OccurrencesSupport;
    })(abstractSupport_1.default);
    exports.default = OccurrencesSupport;
});
