/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", './abstractSupport', '../protocol', 'monaco'], function (require, exports, abstractSupport_1, Protocol, monaco) {
    var FormattingSupport = (function (_super) {
        __extends(FormattingSupport, _super);
        function FormattingSupport() {
            _super.apply(this, arguments);
            this.autoFormatTriggerCharacters = [';', '}' /*, '\n'*/];
        }
        FormattingSupport.prototype.formatDocument = function (resource, options) {
            if (this.isInMemory(resource)) {
                return monaco.Promise.as([]);
            }
            var model = this._modelService.getModel(resource), versionId = model.getVersionId(), request;
            request = {
                Filename: resource.fsPath,
                ExpandTab: options.insertSpaces
            };
            return this.server().makeRequest(Protocol.CodeFormat, request).then(function (res) {
                if (model.getVersionId() !== versionId) {
                    return null;
                }
                if (!res.Buffer) {
                    return null;
                }
                var edit = {
                    text: res.Buffer,
                    range: {
                        startLineNumber: 1,
                        startColumn: 1,
                        endLineNumber: model.getLineCount(),
                        endColumn: model.getLineMaxColumn(model.getLineCount())
                    }
                };
                return [edit];
            });
        };
        FormattingSupport.prototype.formatRange = function (resource, range, options) {
            if (this.isInMemory(resource)) {
                return monaco.Promise.as([]);
            }
            var model = this._modelService.getModel(resource), versionId = model.getVersionId(), request;
            request = {
                Filename: resource.fsPath,
                Line: range.startLineNumber,
                Column: range.startColumn,
                EndLine: range.endLineNumber,
                EndColumn: range.endColumn
            };
            return this.server().makeRequest(Protocol.FormatRange, request).then(function (res) {
                if (!res || !Array.isArray(res.Changes)) {
                    return null;
                }
                if (model.getVersionId() !== versionId) {
                    return null;
                }
                return res.Changes.map(FormattingSupport.asEditOptionation);
            });
        };
        FormattingSupport.prototype.formatAfterKeystroke = function (resource, position, ch, options) {
            if (this.isInMemory(resource)) {
                return monaco.Promise.as([]);
            }
            var model = this._modelService.getModel(resource), versionId = model.getVersionId(), request;
            request = {
                Filename: resource.fsPath,
                Line: position.lineNumber,
                Column: position.column,
                Character: ch
            };
            return this.server().makeRequest(Protocol.FormatAfterKeystroke, request).then(function (res) {
                if (!res || !Array.isArray(res.Changes)) {
                    return null;
                }
                if (model.getVersionId() !== versionId) {
                    return null;
                }
                return res.Changes.map(FormattingSupport.asEditOptionation);
            });
        };
        FormattingSupport.asEditOptionation = function (change) {
            return {
                text: change.NewText,
                range: {
                    startLineNumber: change.StartLine,
                    startColumn: change.StartColumn,
                    endLineNumber: change.EndLine,
                    endColumn: change.EndColumn
                }
            };
        };
        return FormattingSupport;
    })(abstractSupport_1.default);
    exports.default = FormattingSupport;
});
