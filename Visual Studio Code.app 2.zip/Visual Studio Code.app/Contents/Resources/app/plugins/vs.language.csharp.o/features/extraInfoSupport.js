/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", '../documentation', './abstractSupport', '../protocol', 'monaco'], function (require, exports, documentation, abstractSupport_1, Protocol, monaco) {
    var ExtraInfoSupport = (function (_super) {
        __extends(ExtraInfoSupport, _super);
        function ExtraInfoSupport() {
            _super.apply(this, arguments);
        }
        ExtraInfoSupport.prototype.computeInfo = function (resource, position) {
            var _this = this;
            if (this.isInMemory(resource)) {
                return monaco.Promise.as(null);
            }
            var request = {
                Filename: resource.fsPath,
                Line: position.lineNumber,
                Column: position.column,
                IncludeDocumentation: true
            };
            return this.server().makeRequest(Protocol.TypeLookup, request).then(function (value) {
                if (!value || !value.Type) {
                    return null;
                }
                var word = _this._modelService.getModel(resource).getWordAtPosition(position), range;
                if (word) {
                    range = { startLineNumber: position.lineNumber, startColumn: word.startColumn, endLineNumber: position.lineNumber, endColumn: word.endColumn };
                }
                else {
                    range = { startLineNumber: position.lineNumber, startColumn: position.column, endLineNumber: position.lineNumber, endColumn: position.column };
                }
                return {
                    value: '',
                    range: range,
                    className: 'typeInfo',
                    htmlContent: [
                        { className: 'type', text: value.Type },
                        documentation.formatted(value.Documentation)
                    ]
                };
            });
        };
        return ExtraInfoSupport;
    })(abstractSupport_1.default);
    exports.default = ExtraInfoSupport;
});
