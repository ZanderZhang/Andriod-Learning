/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", './abstractSupport', '../protocol'], function (require, exports, abstractSupport_1, Protocol) {
    var BufferSyncSupport = (function (_super) {
        __extends(BufferSyncSupport, _super);
        function BufferSyncSupport(modelService, server) {
            _super.call(this, modelService, server);
            this._syncedModels = Object.create(null);
            this._modelService.getModels().forEach(this._onModelAdded, this);
            this._modelService.onModelAdded.add(this._onModelAdded, this);
            this._modelService.onModelRemoved.add(this._onModelRemoved, this);
        }
        BufferSyncSupport.prototype.dispose = function () {
            this._modelService.onModelAdded.remove(this._onModelAdded, this);
            this._modelService.onModelRemoved.remove(this._onModelRemoved, this);
        };
        BufferSyncSupport.prototype._onModelRemoved = function (model) {
            var key = model.getURL().toString();
            if (!this._syncedModels[key]) {
                return;
            }
            this._syncedModels[key].dispose();
            delete this._syncedModels[key];
        };
        BufferSyncSupport.prototype._onModelAdded = function (model) {
            var _this = this;
            if (model.getModeId() !== 'csharp' || this.isInMemory(model.getURL())) {
                return;
            }
            var key = model.getURL().toString();
            this._syncedModels[key] = new SyncedModel(model, model.getURL().fsPath, function () { return _this.server(); });
        };
        return BufferSyncSupport;
    })(abstractSupport_1.default);
    exports.default = BufferSyncSupport;
    var SyncedModel = (function () {
        function SyncedModel(model, filename, server) {
            this._model = model;
            this._filename = filename;
            this._server = server;
            this._model.onContentChanged.add(this._onContentChanged, this);
        }
        SyncedModel.prototype.dispose = function () {
            this._model.onContentChanged.remove(this._onContentChanged, this);
        };
        SyncedModel.prototype._onContentChanged = function (events) {
            //		https://github.com/OmniSharp/omnisharp-roslyn/issues/112
            //		this._changeBuffer(events);
            this._updateBuffer();
        };
        SyncedModel.prototype._changeBuffer = function (events) {
            var _this = this;
            for (var i = 0, len = events.length; i < len; i++) {
                var event = events[i];
                var req = {
                    FileName: this._filename,
                    StartLine: event.range.startLineNumber,
                    StartColumn: event.range.startColumn,
                    EndLine: event.range.endLineNumber,
                    EndColumn: event.range.endColumn,
                    NewText: event.text
                };
                this._server().makeRequest(Protocol.ChangeBuffer, req).then(null, function (err) {
                    return _this._updateBuffer();
                });
            }
        };
        SyncedModel.prototype._updateBuffer = function () {
            this._server().makeRequest(Protocol.UpdateBuffer, {
                Buffer: abstractSupport_1.default.buffer(this._model),
                Filename: this._filename
            }).done(null, function (err) {
                console.error(err);
            });
        };
        return SyncedModel;
    })();
});
