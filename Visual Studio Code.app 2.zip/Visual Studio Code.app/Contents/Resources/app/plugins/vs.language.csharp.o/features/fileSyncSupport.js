/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../../declares.d.ts" />
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", './abstractSupport', '../protocol'], function (require, exports, abstractSupport_1, Protocol) {
    var BufferSyncSupport = (function (_super) {
        __extends(BufferSyncSupport, _super);
        function BufferSyncSupport(modelService, fileSystemEventService, server) {
            _super.call(this, modelService, server);
            this._watcher = fileSystemEventService.createWatcher();
            this._watcher.onFileChange.add(this._onFileSystemEvent, this);
        }
        BufferSyncSupport.prototype.dispose = function () {
            this._watcher.onFileChange.remove(this._onFileSystemEvent, this);
            this._watcher.dispose();
        };
        BufferSyncSupport.prototype._onFileSystemEvent = function (event) {
            if (event.resource.fsPath.indexOf('.git') !== -1) {
                return;
            }
            var req = { Filename: event.resource.fsPath };
            this.server().makeRequest(Protocol.FilesChanged, [req]).done(undefined, function (err) {
                console.warn('[o] failed to forward file change event for ' + event.resource.fsPath, err);
            });
        };
        return BufferSyncSupport;
    })(abstractSupport_1.default);
    exports.default = BufferSyncSupport;
});
