/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", './abstractSupport', '../protocol', 'monaco'], function (require, exports, abstractSupport_1, protocol_1, monaco) {
    var QuickFixSupport = (function (_super) {
        __extends(QuickFixSupport, _super);
        function QuickFixSupport(modelService, configService, server) {
            var _this = this;
            _super.call(this, modelService, server);
            configService.loadConfiguration('csharp')
                .then(function (config) { return _this._disabled = config && config['disableCodeActions']; });
        }
        QuickFixSupport.prototype.getQuickFixes = function (resource, range) {
            if (this._disabled || this.isInMemory(resource)) {
                return monaco.Promise.as(null);
            }
            var req = {
                Filename: resource.fsPath,
                Selection: QuickFixSupport._asRange(range)
            };
            return this.server().makeRequest(protocol_1.V2.GetCodeActions, req).then(function (response) {
                return response.CodeActions.map(function (ca, index, arr) {
                    return { label: ca.Name, id: ca.Identifier, score: index };
                });
            }, function (error) {
                return monaco.Promise.wrapError('Problem invoking \'GetCodeActions\' on OmniSharp server: ' + error);
            });
        };
        QuickFixSupport.prototype.runQuickFixAction = function (resource, range, id) {
            if (this.isInMemory(resource)) {
                return monaco.Promise.as(null);
            }
            var req = {
                Filename: resource.fsPath,
                Selection: QuickFixSupport._asRange(range),
                Identifier: id,
                WantsTextChanges: true
            };
            return this.server().makeRequest(protocol_1.V2.RunCodeAction, req).then(function (response) {
                var edits = [];
                for (var _i = 0, _a = response.Changes; _i < _a.length; _i++) {
                    var modifiedFile = _a[_i];
                    var resource_1 = monaco.URI.file(modifiedFile.FileName);
                    for (var _b = 0, _c = modifiedFile.Changes; _b < _c.length; _b++) {
                        var change = _c[_b];
                        edits.push(QuickFixSupport._convert(resource_1, change));
                    }
                }
                return { edits: edits };
            }, function (error) {
                return monaco.Promise.wrapError('Problem invoking \'RunCodeAction\' on OmniSharp server: ' + error);
            });
        };
        QuickFixSupport._asRange = function (range) {
            var startLineNumber = range.startLineNumber, startColumn = range.startColumn, endLineNumber = range.endLineNumber, endColumn = range.endColumn;
            return {
                Start: { Line: startLineNumber, Column: startColumn },
                End: { Line: endLineNumber, Column: endColumn }
            };
        };
        QuickFixSupport._convert = function (resource, change) {
            return {
                resource: resource,
                newText: change.NewText,
                range: {
                    startLineNumber: change.StartLine,
                    startColumn: change.StartColumn,
                    endLineNumber: change.EndLine,
                    endColumn: change.EndColumn
                }
            };
        };
        return QuickFixSupport;
    })(abstractSupport_1.default);
    exports.default = QuickFixSupport;
});
