/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", './abstractSupport', '../protocol', 'monaco'], function (require, exports, abstractSupport_1, Protocol, monaco) {
    var CodeLensSupport = (function (_super) {
        __extends(CodeLensSupport, _super);
        function CodeLensSupport() {
            _super.apply(this, arguments);
        }
        CodeLensSupport.prototype.enableCodeLens = function () {
            return true;
        };
        CodeLensSupport.prototype.findCodeLensSymbols = function (resource) {
            if (this.isInMemory(resource)) {
                return monaco.Promise.as([]);
            }
            return this.server().makeRequest(Protocol.CurrentFileMembersAsTree, {
                Filename: resource.fsPath
            }).then(function (tree) {
                var ret = [];
                tree.TopLevelTypeDefinitions.forEach(function (node) { return CodeLensSupport._toCodeLensSymbol(ret, node); });
                return ret;
            });
        };
        CodeLensSupport._toCodeLensSymbol = function (container, node) {
            if (node.Kind === 'MethodDeclaration' && CodeLensSupport.filteredSymbolNames[node.Location.Text]) {
                return;
            }
            var ret = {
                range: {
                    startLineNumber: node.Location.Line,
                    startColumn: node.Location.Column,
                    endLineNumber: node.Location.EndLine,
                    endColumn: node.Location.EndColumn
                }
            };
            if (node.ChildNodes) {
                node.ChildNodes.forEach(function (value) { return CodeLensSupport._toCodeLensSymbol(container, value); });
            }
            container.push(ret);
        };
        CodeLensSupport.prototype.findCodeLensReferences = function (resource, requests) {
            var _this = this;
            if (this.isInMemory(resource)) {
                return monaco.Promise.as(null);
            }
            var resultPromises = requests.map(function (request) {
                return _this.server().makeRequest(Protocol.FindUsages, {
                    Filename: resource.fsPath,
                    Line: request.position.lineNumber,
                    Column: request.position.column,
                    OnlyThisFile: false,
                    ExcludeDefinition: true
                }).then(function (res) {
                    return !res || !Array.isArray(res.QuickFixes)
                        ? []
                        : res.QuickFixes.map(CodeLensSupport._asReference).filter(function (r) { return !monaco.Range.containsPosition(r.range, request.position); });
                });
            });
            return monaco.Promise.join(resultPromises).then(function (allReferences) {
                return {
                    references: allReferences
                };
            });
        };
        CodeLensSupport._asReference = function (quickFix) {
            return {
                resourceUrl: new monaco.URL(monaco.URI.file(quickFix.FileName)),
                range: {
                    startLineNumber: quickFix.Line,
                    startColumn: quickFix.Column,
                    endLineNumber: quickFix.EndLine,
                    endColumn: quickFix.EndColumn
                }
            };
        };
        CodeLensSupport.filteredSymbolNames = {
            'Equals': true,
            'Finalize': true,
            'GetHashCode': true,
            'ToString': true
        };
        return CodeLensSupport;
    })(abstractSupport_1.default);
    exports.default = CodeLensSupport;
});
