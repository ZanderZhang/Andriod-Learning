/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports", '../documentation', './abstractSupport', '../protocol'], function (require, exports, documentation, abstractSupport_1, Protocol) {
    var ParameterHintsSupport = (function (_super) {
        __extends(ParameterHintsSupport, _super);
        function ParameterHintsSupport() {
            _super.apply(this, arguments);
        }
        Object.defineProperty(ParameterHintsSupport.prototype, "triggerCharacters", {
            get: function () {
                return ['(', ','];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ParameterHintsSupport.prototype, "excludeTokens", {
            get: function () {
                return ['comment.cs', 'string.cs', 'number.cs'];
            },
            enumerable: true,
            configurable: true
        });
        ParameterHintsSupport.prototype.getParameterHints = function (resource, position) {
            var req = {
                Filename: resource.fsPath,
                Line: position.lineNumber,
                Column: position.column
            };
            return this.server().makeRequest(Protocol.SignatureHelp, req).then(function (res) {
                var ret = {
                    currentSignature: res.ActiveSignature,
                    currentParameter: res.ActiveParameter,
                    signatures: []
                };
                res.Signatures.forEach(function (signature) {
                    var _signature = {
                        documentation: documentation.plain(signature.Documentation),
                        label: signature.Name + '(',
                        parameters: []
                    };
                    signature.Parameters.forEach(function (parameter, i, a) {
                        var _parameter = {
                            documentation: documentation.plain(parameter.Documentation),
                            label: parameter.Label,
                            signatureLabelOffset: _signature.label.length,
                            signatureLabelEnd: _signature.label.length + parameter.Label.length
                        };
                        _signature.parameters.push(_parameter);
                        _signature.label += _parameter.label;
                        if (i < a.length - 1) {
                            _signature.label += ', ';
                        }
                    });
                    _signature.label += ')';
                    ret.signatures.push(_signature);
                });
                return ret;
            });
        };
        return ParameterHintsSupport;
    })(abstractSupport_1.default);
    exports.default = ParameterHintsSupport;
});
