/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports", 'monaco', './features/declarationSupport', './features/codeLensSupport', './features/occurrencesSupport', './features/outlineSupport', './features/quickFixSupport', './features/referenceSupport', './features/extraInfoSupport', './features/renameSupport', './features/formattingSupport', './features/suggestSupport', './features/bufferSyncSupport', './features/navigateTypesSupport', './features/diagnosticsSupport', './features/parameterHintsSupport', './features/fileSyncSupport', './omnisharpServer.native', './omnisharp'], function (require, exports, monaco, declarationSupport_1, codeLensSupport_1, occurrencesSupport_1, outlineSupport_1, quickFixSupport_1, referenceSupport_1, extraInfoSupport_1, renameSupport_1, formattingSupport_1, suggestSupport_1, bufferSyncSupport_1, navigateTypesSupport_1, diagnosticsSupport_1, parameterHintsSupport_1, fileSyncSupport_1, omnisharpServer, omnisharp) {
    var myModeId = 'csharp';
    function activate(_ctx) {
        var modelService = _ctx.modelService, markerService = _ctx.markerService, configurationService = _ctx.configurationService, fileSystemEventService = _ctx.fileSystemEventService;
        var server = new omnisharpServer.StdioOmnisharpServer(configurationService);
        var diagnosticsAdvisor = new diagnosticsSupport_1.Advisor(server);
        var listener;
        function onOmnisharpServerEvent(kind, state) {
            if (kind !== 'stateChanged' || state !== omnisharp.ServerState.Started) {
                return;
            }
            monaco.Modes.DeclarationSupport.register('csharp', new declarationSupport_1.default(modelService, server));
            monaco.Modes.CodeLensSupport.register('csharp', new codeLensSupport_1.default(modelService, server));
            monaco.Modes.OccurrencesSupport.register('csharp', new occurrencesSupport_1.default(modelService, server));
            monaco.Modes.OutlineSupport.register('csharp', new outlineSupport_1.default(modelService, server));
            monaco.Modes.ReferenceSupport.register('csharp', new referenceSupport_1.default(modelService, server));
            monaco.Modes.ExtraInfoSupport.register('csharp', new extraInfoSupport_1.default(modelService, server));
            monaco.Modes.RenameSupport.register('csharp', new renameSupport_1.default(modelService, server));
            monaco.Modes.FormattingSupport.register('csharp', new formattingSupport_1.default(modelService, server));
            monaco.Modes.SuggestSupport.register('csharp', new suggestSupport_1.default(modelService, server));
            monaco.Modes.NavigateTypesSupport.register('csharp', new navigateTypesSupport_1.default(modelService, server));
            monaco.Modes.ParameterHintsSupport.register('csharp', new parameterHintsSupport_1.default(modelService, server));
            monaco.Modes.QuickFixSupport.register('csharp', new quickFixSupport_1.default(modelService, configurationService, server));
            new fileSyncSupport_1.default(modelService, fileSystemEventService, server);
            new bufferSyncSupport_1.default(modelService, server);
            new diagnosticsSupport_1.DiagnosticsSupport(modelService, markerService, server, diagnosticsAdvisor);
            listener.dispose();
        }
        listener = server.addListener({ onOmnisharpServerEvent: onOmnisharpServerEvent });
        return monaco.Promise.as({
            start: function (solutionPath) { return server.start(solutionPath); },
            stop: function () { return server.stop(); },
            makeRequest: function (path, data) { return server.makeRequest(path, data); },
            addListener: function (listener) {
                var ret = server.addListener(listener);
                return {
                    dispose: function () { return ret.dispose(); }
                };
            }
        });
    }
    exports.activate = activate;
});
