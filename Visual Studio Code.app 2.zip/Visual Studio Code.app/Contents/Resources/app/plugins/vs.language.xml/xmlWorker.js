/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports", 'vs/languages/lib/common/beautify-html', 'monaco'], function (require, exports, beautifyHTML, monaco) {
    var modelService = null;
    function activate(_ctx) {
        modelService = _ctx.modelService;
        return monaco.Promise.as({
            formatDocument: formatDocument,
            formatRange: formatRange
        });
    }
    exports.activate = activate;
    function formatDocument(resource, options) {
        return format(resource, null, options);
    }
    exports.formatDocument = formatDocument;
    function formatRange(resource, range, options) {
        return format(resource, range, options);
    }
    exports.formatRange = formatRange;
    function format(resource, range, options) {
        var model = modelService.getModel(resource);
        var value = range ? model.getValueInRange(range) : model.getValue();
        var result = beautifyHTML.html_beautify(value, {
            'indent_size': options.insertSpaces ? options.tabSize : 1,
            'indent_char': options.insertSpaces ? ' ' : '\t',
            'wrap_line_length': 256
        });
        return monaco.Promise.as([{
                range: range,
                text: result
            }]);
    }
});
