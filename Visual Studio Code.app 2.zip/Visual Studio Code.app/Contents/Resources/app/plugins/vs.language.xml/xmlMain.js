/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports", './xmlDef', 'monaco'], function (require, exports, languageDef, monaco) {
    function activate(_ctx) {
        monaco.Modes.registerMonarchDefinition('xml', languageDef.language);
        var myWorker = monaco.Modes.loadInBackgroundWorker(require.toUrl('./xmlWorker.js'));
        monaco.Modes.FormattingSupport.register('xml', {
            formatDocument: function (resource, options) {
                return myWorker.then(function (w) { return w.formatDocument(resource, options); });
            },
            formatRange: function (resource, range, options) {
                return myWorker.then(function (w) { return w.formatRange(resource, range, options); });
            }
        });
        return null;
    }
    exports.activate = activate;
});
