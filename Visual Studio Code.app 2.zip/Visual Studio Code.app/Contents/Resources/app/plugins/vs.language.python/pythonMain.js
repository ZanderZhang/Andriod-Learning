/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports", './pythonDef', 'monaco'], function (require, exports, pythonDef, monaco) {
    monaco.Modes.registerMonarchDefinition('python', pythonDef.language);
    var InplaceReplaceSupport = monaco.Modes.InplaceReplaceSupport;
    InplaceReplaceSupport.register('python', InplaceReplaceSupport.create({
        textReplace: function (value, up) {
            return InplaceReplaceSupport.valueSetReplace(['True', 'False'], value, up);
        }
    }));
});
