/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports", './dockerfileDef', 'monaco', './extraInfoSupport'], function (require, exports, dockerfileDef, monaco_1, extraInfoSupport_1) {
    monaco_1.Modes.registerMonarchDefinition('dockerfile', dockerfileDef.language);
    function activate(_ctx) {
        var MODE_ID = 'dockerfile';
        monaco_1.Modes.ExtraInfoSupport.register(MODE_ID, new extraInfoSupport_1.ExtraInfoSupport(_ctx));
        return monaco_1.Promise.as(null);
    }
    exports.activate = activate;
});
