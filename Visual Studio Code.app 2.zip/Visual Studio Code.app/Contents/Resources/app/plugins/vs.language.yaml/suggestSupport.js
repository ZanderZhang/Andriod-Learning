/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../declares.d.ts" />
'use strict';
define(["require", "exports", 'monaco', './parser', './hubAPI'], function (require, exports, monaco, parser, hub) {
    function isDockerCompose(resource) {
        return /docker\-compose\.yml$/.test(resource.toString());
    }
    var SuggestSupport = (function () {
        function SuggestSupport(ctx) {
            this.triggerCharacters = [];
            this.excludeTokens = [];
            this._modelService = ctx.modelService;
        }
        SuggestSupport.prototype.suggest = function (resource, position) {
            if (!isDockerCompose(resource)) {
                return monaco.Promise.as(null);
            }
            var model = this._modelService.getModel(resource);
            var line = model.getValueInRange({
                startLineNumber: position.lineNumber,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: model.getLineMaxColumn(position.lineNumber)
            });
            if (line.length === 0) {
                // empty line
                return monaco.Promise.as([this._suggestKeys('')]);
            }
            var word = model.getWordAtPosition(position);
            var textBefore = line.substring(0, position.column - 1);
            if (/^\s*[\w_]*$/.test(textBefore)) {
                // on the first token
                return monaco.Promise.as([this._suggestKeys(word ? word.word : '')]);
            }
            var imageTextWithQuoteMatch = textBefore.match(/^\s*image\s*\:\s*"([^"]*)$/);
            if (imageTextWithQuoteMatch) {
                var imageText = imageTextWithQuoteMatch[1];
                return this._suggestImages(imageText, true);
            }
            var imageTextWithoutQuoteMatch = textBefore.match(/^\s*image\s*\:\s*([\w\:\/]*)/);
            if (imageTextWithoutQuoteMatch) {
                var imageText = imageTextWithoutQuoteMatch[1];
                return this._suggestImages(imageText, false);
            }
            return monaco.Promise.as([]);
        };
        SuggestSupport.prototype._suggestImages = function (word, hasLeadingQuote) {
            return this._suggestHubImages(word).then(function (results) {
                return [{
                        incomplete: true,
                        currentWord: (hasLeadingQuote ? '"' + word : word),
                        suggestions: results
                    }];
            });
        };
        SuggestSupport.prototype._suggestHubImages = function (word) {
            return hub.searchImagesInRegistryHub(word, true).then(function (results) {
                return results.map(function (image) {
                    var stars = '';
                    if (image.star_count > 0) {
                        stars = ' ' + image.star_count + ' ' + (image.star_count > 1 ? 'stars' : 'star');
                    }
                    return {
                        label: image.name,
                        codeSnippet: '"' + image.name + '"',
                        type: 'value',
                        documentationLabel: image.description,
                        typeLabel: hub.tagsForImage(image) + stars
                    };
                });
            });
        };
        SuggestSupport.prototype._suggestKeys = function (word) {
            return {
                currentWord: word,
                suggestions: Object.keys(parser.RAW_KEY_INFO).map(function (ruleName) {
                    return {
                        label: ruleName,
                        codeSnippet: ruleName + ': ',
                        type: 'property',
                        documentationLabel: parser.RAW_KEY_INFO[ruleName]
                    };
                })
            };
        };
        return SuggestSupport;
    })();
    exports.SuggestSupport = SuggestSupport;
});
