/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
/// <reference path="../declares.d.ts" />
'use strict';
define(["require", "exports", 'monaco', './extraInfoSupport', './suggestSupport'], function (require, exports, monaco, _extraInfoSupport, _suggestSupport) {
    function activate(_ctx) {
        var MODE_ID = 'yaml';
        monaco.Modes.ExtraInfoSupport.register(MODE_ID, new _extraInfoSupport.ExtraInfoSupport(_ctx));
        monaco.Modes.SuggestSupport.register(MODE_ID, new _suggestSupport.SuggestSupport(_ctx));
        monaco.Modes.CommentsSupport.register(MODE_ID, {
            commentsConfiguration: {
                lineCommentTokens: ['#']
            }
        });
        return monaco.Promise.as(null);
    }
    exports.activate = activate;
});
