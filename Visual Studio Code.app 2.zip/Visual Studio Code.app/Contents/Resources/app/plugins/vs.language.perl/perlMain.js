/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports", 'monaco'], function (require, exports, monaco) {
    var commentsSupport = {
        commentsConfiguration: {
            lineCommentTokens: ['#']
        }
    };
    monaco.Modes.CommentsSupport.register('perl', commentsSupport);
    monaco.Modes.CommentsSupport.register('perl6', commentsSupport);
});
